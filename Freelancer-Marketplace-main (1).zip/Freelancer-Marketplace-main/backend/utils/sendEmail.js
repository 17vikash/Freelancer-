const nodemailer = require("nodemailer");

/**
 * Utility to send email via Nodemailer SMTP or log OTP for testing
 */
const sendEmail = async (options) => {
  try {
    if (process.env.SMTP_HOST && process.env.SMTP_USER) {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT || 587,
        secure: process.env.SMTP_SECURE === "true",
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      });

      const message = {
        from: `"${process.env.FROM_NAME || 'Freelancer Marketplace'}" <${process.env.FROM_EMAIL || 'no-reply@freelancermarketplace.com'}>`,
        to: options.email,
        subject: options.subject,
        html: options.html
      };

      const info = await transporter.sendMail(message);
      console.log(`[EMAIL DISPATCH] Email successfully sent to ${options.email}. Message ID: ${info.messageId}`);
      return { success: true, messageId: info.messageId };
    } else {
      console.log(`\n==================================================`);
      console.log(`📧 [EMAIL MOCK / CONSOLE VERIFICATION]`);
      console.log(`TO: ${options.email}`);
      console.log(`SUBJECT: ${options.subject}`);
      console.log(`VERIFICATION CODE (OTP): ${options.otp}`);
      console.log(`==================================================\n`);
      return { success: true, mock: true, otp: options.otp };
    }
  } catch (err) {
    console.error(`[EMAIL ERROR] Failed to send email to ${options.email}:`, err.message);
    // Don't crash auth flow if mail transport fails, log error clearly
    return { success: false, error: err.message, otp: options.otp };
  }
};

module.exports = sendEmail;
