const mongoose = require("mongoose");

const JobSchema = new mongoose.Schema({
  client: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },
  title: {
    type: String,
    required: [true, "Job title is required"],
    trim: true
  },
  description: {
    type: String,
    required: [true, "Job description is required"]
  },
  category: {
    type: String,
    required: [true, "Category is required"],
    enum: ["Web Development", "Mobile Apps", "AI & Data", "Design & Creative"]
  },
  budgetType: {
    type: String,
    enum: ["fixed", "hourly"],
    default: "fixed"
  },
  budgetAmount: {
    type: Number,
    required: [true, "Budget amount is required"]
  },
  skills: {
    type: [String],
    required: [true, "At least one skill is required"]
  },
  deadline: {
    type: String,
    required: [true, "Target deadline is required"]
  },
  status: {
    type: String,
    enum: ["open", "in_progress", "completed"],
    default: "open"
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Job", JobSchema);
