const mongoose = require("mongoose");

const PortfolioItemSchema = new mongoose.Schema({
  title: String,
  image: String,
  link: String
});

const FreelancerProfileSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
    unique: true
  },
  title: {
    type: String,
    default: "Senior Full-Stack Developer"
  },
  bio: {
    type: String,
    default: "Passionate software engineer crafting clean, high-performance web applications and mobile UI."
  },
  skills: {
    type: [String],
    default: ["React", "Node.js", "TypeScript"]
  },
  hourlyRate: {
    type: Number,
    default: 1200
  },
  portfolio: [PortfolioItemSchema],
  avgRating: {
    type: Number,
    default: 5.0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("FreelancerProfile", FreelancerProfileSchema);
