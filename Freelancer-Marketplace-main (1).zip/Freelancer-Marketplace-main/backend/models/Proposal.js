const mongoose = require("mongoose");

const ProposalSchema = new mongoose.Schema({
  job: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Job",
    required: true
  },
  freelancer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },
  coverLetter: {
    type: String,
    required: [true, "Cover letter is required"]
  },
  bidAmount: {
    type: Number,
    required: [true, "Bid amount is required"]
  },
  duration: {
    type: String,
    required: [true, "Estimated duration is required"]
  },
  status: {
    type: String,
    enum: ["pending", "accepted", "rejected"],
    default: "pending"
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Proposal", ProposalSchema);
