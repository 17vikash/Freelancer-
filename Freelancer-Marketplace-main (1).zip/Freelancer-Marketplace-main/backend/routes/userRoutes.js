const express = require("express");
const router = express.Router();
const { updateProfile, updatePassword } = require("../controllers/userController");
const { protect } = require("../middleware/auth");

router.put("/me", protect, updateProfile);
router.put("/me/password", protect, updatePassword);

module.exports = router;
