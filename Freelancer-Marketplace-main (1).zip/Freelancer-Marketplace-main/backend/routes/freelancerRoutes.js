const express = require("express");
const router = express.Router();
const { 
  getFreelancerProposals, 
  getFreelancerStats, 
  getFreelancerProfile, 
  getFreelancerReviews 
} = require("../controllers/freelancerController");
const { protect, authorizeRole } = require("../middleware/auth");

router.get("/me/proposals", protect, authorizeRole("freelancer"), getFreelancerProposals);
router.get("/me/stats", protect, authorizeRole("freelancer"), getFreelancerStats);
router.get("/:id", getFreelancerProfile);
router.get("/:id/reviews", getFreelancerReviews);

module.exports = router;
