const express = require("express");
const router = express.Router();
const { updateProposalStatus } = require("../controllers/proposalController");
const { protect, authorizeRole } = require("../middleware/auth");

router.put("/:id", protect, authorizeRole("client"), updateProposalStatus);
router.put("/:id/status", protect, authorizeRole("client"), updateProposalStatus);

module.exports = router;
