const express = require("express");
const router = express.Router();
const { signup, login, getMe, googleAuth, verifyOTP, resendOTP } = require("../controllers/authController");
const { protect } = require("../middleware/auth");

router.post("/signup", signup);
router.post("/verify-otp", verifyOTP);
router.post("/resend-otp", resendOTP);
router.post("/login", login);
router.post("/google", googleAuth);
router.get("/me", protect, getMe);

module.exports = router;
