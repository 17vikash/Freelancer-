const express = require("express");
const router = express.Router();
const { getClientJobs, getClientStats } = require("../controllers/clientController");
const { protect, authorizeRole } = require("../middleware/auth");

router.get("/me/jobs", protect, authorizeRole("client"), getClientJobs);
router.get("/me/stats", protect, authorizeRole("client"), getClientStats);

module.exports = router;
