const express = require("express");
const router = express.Router();
const { getJobs, getJobById, createJob, updateJob, deleteJob } = require("../controllers/jobController");
const { createProposal, getJobProposals } = require("../controllers/proposalController");
const { createReview } = require("../controllers/reviewController");
const { protect, authorizeRole } = require("../middleware/auth");

router.route("/")
  .get(getJobs)
  .post(protect, authorizeRole("client"), createJob);

router.route("/:id")
  .get(getJobById)
  .put(protect, authorizeRole("client"), updateJob)
  .delete(protect, authorizeRole("client"), deleteJob);

// Nested proposal & review routes
router.post("/:id/proposals", protect, authorizeRole("freelancer"), createProposal);
router.get("/:id/proposals", protect, authorizeRole("client"), getJobProposals);
router.post("/:id/reviews", protect, createReview);

module.exports = router;
